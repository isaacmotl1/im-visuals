/* --------------------------------------------------
   Image data
   These are intentionally easy-to-replace placeholder URLs. The comments
   name the local files to add later in each category folder.
-------------------------------------------------- */
const imageSources = [
  "photo-1500534623283-312aade485b7", "photo-1464822759023-fed622ff2c3b", "photo-1511497584788-876760111969", "photo-1500530855697-b586d89ba3ee",
  "photo-1501854140801-50d01698950b", "photo-1443632864897-14973fa006cf", "photo-1470770841072-f978cf4d019e", "photo-1454496522488-7a8e488e8606",
  "photo-1517836357463-d25dfeac3438", "photo-1517838277536-f5f99be5019c", "photo-1517963879433-6ad2b056d712", "photo-1517838277536-f5f99be5019c",
  "photo-1518611012118-696072aa579a", "photo-1538805060514-97d9cc17730c", "photo-1517260739337-6799d239ce83", "photo-1483721310020-03333e577078",
  "photo-1506629905607-d405b7a30db6", "photo-1542291026-7eec264c27ff", "photo-1486218119243-13883505764c", "photo-1517836357463-d25dfeac3438",
  "photo-1472396961693-142e6e269027", "photo-1552728089-57bdde30beb3", "photo-1444464666168-49d633b86797", "photo-1474511320723-07a8dd4e6c00",
  "photo-1504006833117-8886a355efbf", "photo-1517841905240-472988babdf9", "photo-1534528741775-53994a69daeb", "photo-1531123897727-8f129e1688ce",
  "photo-1519085360753-af0119f7cbe7", "photo-1500648767791-00dcc994a43e", "photo-1539571696357-5a69c17a67c6", "photo-1524504388940-b1c1722653e1",
  "photo-1436491865332-7a61a109cc05", "photo-1474302770737-173ee21bab63", "photo-1529074963764-98f0d7c160b8", "photo-1436491865332-7a61a109cc05",
  "photo-1474302770737-173ee21bab63", "photo-1517479149777-5f3b1511d5ad", "photo-1529074963764-98f0d7c160b8", "photo-1436491865332-7a61a109cc05",
  "photo-1534088568595-a066f410bcda", "photo-1542296332-2e4473faf563", "photo-1583395838144-8f98f9a6c1f4", "photo-1593941707882-a5bac6861d75"
];

const categories = [
  { id: "landscape", label: "Landscape", start: 0, count: 8, titles: ["After the Rain", "High Country", "Weather Line", "Still Water", "The Long Way", "North Face", "At First Light", "Quiet Terrain"] },
  { id: "sports", label: "Sports", start: 8, count: 12, titles: ["The Work", "Before the Bell", "Third Quarter", "On the Line", "Endurance", "No. 16", "Lanes", "Last Light", "Interval", "Game Day", "The Climb", "Between Rounds"] },
  { id: "wildlife", label: "Wildlife", start: 20, count: 8, titles: ["Field Notes I", "Stillness", "Open Country", "Watchful", "Wild Hours", "Along the Ridge", "Passing Through", "Instinct"] },
  { id: "portraits", label: "Portraits", start: 24, count: 8, titles: ["Maria", "Ari", "Sofia", "June", "Milan", "Dara", "Lewis", "Celia"] },
  { id: "aviation", label: "Aviation", start: 32, count: 8, titles: ["Blue Hour", "On Final", "Takeoff", "Flight Line", "Altitude", "Runway 04", "Clear Skies", "Wing Study"] }
];

function imageUrl(source, width = 900) { return `https://images.unsplash.com/${source}?auto=format&fit=crop&w=${width}&q=85`; }
function fileName(category, number) { return `images/${category}/${category.slice(0, -1)}-${String(number).padStart(2, "0")}.jpg`; }

// Creates the full 44-image archive: Landscape 8, Sports 12, Wildlife 8, Portraits 8, Aviation 8.
const portfolioItems = categories.flatMap((category) => Array.from({ length: category.count }, (_, index) => ({
  id: `${category.id}-${index + 1}`,
  category: category.id,
  categoryLabel: category.label,
  title: category.titles[index],
  // Replace this placeholder with the following local image:
  localFile: fileName(category.id, index + 1),
  src: imageUrl(imageSources[category.start + index]),
  alt: `${category.label} photograph placeholder: ${category.titles[index]}`
})));

/* --------------------------------------------------
   Reusable card builders
-------------------------------------------------- */
function createImageCard(item, className = "") {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `image-card ${className}`;
  button.dataset.imageId = item.id;
  button.setAttribute("aria-label", `Open ${item.title} in image viewer`);
  button.innerHTML = `<img src="${item.src}" alt="${item.alt}" loading="lazy"><span class="image-card__label">${item.title}</span>`;
  return button;
}

function renderFeaturedWork() {
  const featuredIds = ["landscape-1", "sports-3", "wildlife-2", "portraits-3", "aviation-1", "landscape-6"];
  const grid = document.querySelector("#featured-grid");
  featuredIds.map((id) => portfolioItems.find((item) => item.id === id)).forEach((item) => grid.append(createImageCard(item)));
}

function renderCategories() {
  const grid = document.querySelector("#category-grid");
  categories.forEach((category) => {
    const item = portfolioItems.find((image) => image.category === category.id);
    const link = document.createElement("a");
    link.className = "category-card";
    link.href = "#portfolio";
    link.dataset.categoryLink = category.id;
    link.innerHTML = `<img src="${item.src}" alt="${category.label} category placeholder" loading="lazy"><span>${category.label}</span>`;
    grid.append(link);
  });
}

function renderPrints() {
  const printIds = ["landscape-2", "wildlife-3", "aviation-4", "sports-8"];
  const printInfo = [
    ["A Matter of Weather", "Dolomites, Italy · 2024", "12 × 18, 20 × 30, 30 × 45 in"],
    ["Open Country", "Wyoming, USA · 2023", "12 × 18, 20 × 30, 30 × 45 in"],
    ["Altitude", "Nevada, USA · 2022", "12 × 18, 20 × 30, 30 × 45 in"],
    ["Last Light", "Utah, USA · 2024", "12 × 18, 20 × 30, 30 × 45 in"]
  ];
  const grid = document.querySelector("#print-grid");
  printIds.map((id) => portfolioItems.find((item) => item.id === id)).forEach((item, index) => {
    const [title, description, sizes] = printInfo[index];
    const card = document.createElement("article");
    card.className = "print-card reveal";
    card.innerHTML = `<div class="print-card__image"><img src="${item.src}" alt="${item.alt}" loading="lazy"></div><div class="print-card__body"><h3>${title}</h3><p>${description}</p><p class="sizes">${sizes}</p><a class="text-link" href="#contact">Inquire <span aria-hidden="true">↗</span></a></div>`;
    grid.append(card);
  });
}

function renderPortfolio(filter = "all") {
  const grid = document.querySelector("#portfolio-grid");
  grid.innerHTML = "";
  portfolioItems.filter((item) => filter === "all" || item.category === filter).forEach((item) => {
    const article = document.createElement("article");
    article.className = "portfolio-item";
    article.innerHTML = `<div class="portfolio-item__image"></div><p class="portfolio-item__meta"><span>${item.title}</span><span>${item.categoryLabel}</span></p>`;
    article.querySelector(".portfolio-item__image").append(createImageCard(item));
    grid.append(article);
  });
}

/* --------------------------------------------------
   Portfolio filters and category links
-------------------------------------------------- */
function setPortfolioFilter(filter) {
  document.querySelectorAll(".filter-button").forEach((button) => button.classList.toggle("is-active", button.dataset.filter === filter));
  renderPortfolio(filter);
}

function initializeFilters() {
  document.querySelectorAll(".filter-button").forEach((button) => button.addEventListener("click", () => setPortfolioFilter(button.dataset.filter)));
  document.querySelectorAll("[data-category-link]").forEach((link) => link.addEventListener("click", () => setPortfolioFilter(link.dataset.categoryLink)));
}

/* --------------------------------------------------
   Accessible image lightbox
-------------------------------------------------- */
let activeImages = portfolioItems;
let activeIndex = 0;
const lightbox = document.querySelector("#lightbox");
const lightboxImage = document.querySelector("#lightbox-image");
const lightboxCaption = document.querySelector("#lightbox-caption");

function showLightboxImage() {
  const item = activeImages[activeIndex];
  lightboxImage.src = item.src;
  lightboxImage.alt = item.alt;
  lightboxCaption.textContent = `${item.title} · ${item.categoryLabel}`;
}

function openLightbox(id) {
  const visibleCategory = document.querySelector(".filter-button.is-active").dataset.filter;
  activeImages = portfolioItems.filter((item) => visibleCategory === "all" || item.category === visibleCategory);
  activeIndex = activeImages.findIndex((item) => item.id === id);
  showLightboxImage();
  lightbox.showModal();
}

function closeLightbox() { lightbox.close(); }
function moveLightbox(direction) { activeIndex = (activeIndex + direction + activeImages.length) % activeImages.length; showLightboxImage(); }
function initializeLightbox() {
  document.addEventListener("click", (event) => { const card = event.target.closest("[data-image-id]"); if (card) openLightbox(card.dataset.imageId); });
  document.querySelector(".lightbox__close").addEventListener("click", closeLightbox);
  document.querySelector(".lightbox__arrow--previous").addEventListener("click", () => moveLightbox(-1));
  document.querySelector(".lightbox__arrow--next").addEventListener("click", () => moveLightbox(1));
  document.addEventListener("keydown", (event) => { if (!lightbox.open) return; if (event.key === "ArrowLeft") moveLightbox(-1); if (event.key === "ArrowRight") moveLightbox(1); if (event.key === "Escape") closeLightbox(); });
  lightbox.addEventListener("click", (event) => { if (event.target === lightbox) closeLightbox(); });
}

/* --------------------------------------------------
   Mobile navigation, scroll header, and animations
-------------------------------------------------- */
function initializeNavigation() {
  const header = document.querySelector(".site-header");
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  const updateHeader = () => header.classList.toggle("is-scrolled", window.scrollY > 25);
  updateHeader(); window.addEventListener("scroll", updateHeader, { passive: true });
  toggle.addEventListener("click", () => { const open = nav.classList.toggle("is-open"); toggle.setAttribute("aria-expanded", open); toggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation"); });
  nav.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => { nav.classList.remove("is-open"); toggle.setAttribute("aria-expanded", "false"); }));
}

function initializeRevealAnimations() {
  const observer = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) { entry.target.classList.add("is-visible"); observer.unobserve(entry.target); } }), { threshold: .12 });
  document.querySelectorAll(".reveal").forEach((element) => observer.observe(element));
}

function initializeSite() {
  renderFeaturedWork(); renderCategories(); renderPrints(); renderPortfolio();
  initializeFilters(); initializeLightbox(); initializeNavigation(); initializeRevealAnimations();
  document.querySelector("#year").textContent = new Date().getFullYear();
}
initializeSite();
